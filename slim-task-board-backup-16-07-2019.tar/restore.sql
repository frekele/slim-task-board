--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.4 (Ubuntu 11.4-1.pgdg16.04+1)
-- Dumped by pg_dump version 11.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE d1m91lf36ouf80;
--
-- Name: d1m91lf36ouf80; Type: DATABASE; Schema: -; Owner: wcdgvfyqvpvazx
--

CREATE DATABASE d1m91lf36ouf80 WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


ALTER DATABASE d1m91lf36ouf80 OWNER TO wcdgvfyqvpvazx;

\connect d1m91lf36ouf80

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: slim_board; Type: TABLE DATA; Schema: public; Owner: wcdgvfyqvpvazx
--

COPY public.slim_board (id, name, description) FROM stdin;
\.
COPY public.slim_board (id, name, description) FROM '$$PATH$$/3861.dat';

--
-- Data for Name: slim_column; Type: TABLE DATA; Schema: public; Owner: wcdgvfyqvpvazx
--

COPY public.slim_column (id, board_id, name, weight) FROM stdin;
\.
COPY public.slim_column (id, board_id, name, weight) FROM '$$PATH$$/3863.dat';

--
-- Data for Name: slim_task; Type: TABLE DATA; Schema: public; Owner: wcdgvfyqvpvazx
--

COPY public.slim_task (id, column_id, name, weight, description, assigned_user_id) FROM stdin;
\.
COPY public.slim_task (id, column_id, name, weight, description, assigned_user_id) FROM '$$PATH$$/3865.dat';

--
-- Data for Name: slim_user; Type: TABLE DATA; Schema: public; Owner: wcdgvfyqvpvazx
--

COPY public.slim_user (id, name, email, password) FROM stdin;
\.
COPY public.slim_user (id, name, email, password) FROM '$$PATH$$/3866.dat';

--
-- Name: board_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wcdgvfyqvpvazx
--

SELECT pg_catalog.setval('public.board_id_seq', 22, true);


--
-- Name: column_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wcdgvfyqvpvazx
--

SELECT pg_catalog.setval('public.column_id_seq', 51, true);


--
-- Name: task_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wcdgvfyqvpvazx
--

SELECT pg_catalog.setval('public.task_id_seq', 49, true);


--
-- Name: user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wcdgvfyqvpvazx
--

SELECT pg_catalog.setval('public.user_id_seq', 10, true);


--
-- PostgreSQL database dump complete
--

