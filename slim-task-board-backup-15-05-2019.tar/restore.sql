--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.2 (Ubuntu 11.2-1.pgdg16.04+1)
-- Dumped by pg_dump version 11.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE d1m91lf36ouf80;
--
-- Name: d1m91lf36ouf80; Type: DATABASE; Schema: -; Owner: wcdgvfyqvpvazx
--

CREATE DATABASE d1m91lf36ouf80 WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


ALTER DATABASE d1m91lf36ouf80 OWNER TO wcdgvfyqvpvazx;

\connect d1m91lf36ouf80

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: slim_board; Type: TABLE; Schema: public; Owner: wcdgvfyqvpvazx
--

CREATE TABLE public.slim_board (
    id integer NOT NULL,
    name character varying(250) NOT NULL,
    description character varying(250)
);


ALTER TABLE public.slim_board OWNER TO wcdgvfyqvpvazx;

--
-- Name: board_id_seq; Type: SEQUENCE; Schema: public; Owner: wcdgvfyqvpvazx
--

CREATE SEQUENCE public.board_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.board_id_seq OWNER TO wcdgvfyqvpvazx;

--
-- Name: board_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: wcdgvfyqvpvazx
--

ALTER SEQUENCE public.board_id_seq OWNED BY public.slim_board.id;


--
-- Name: slim_column; Type: TABLE; Schema: public; Owner: wcdgvfyqvpvazx
--

CREATE TABLE public.slim_column (
    id integer NOT NULL,
    board_id integer NOT NULL,
    name character varying(250) NOT NULL,
    weight integer NOT NULL
);


ALTER TABLE public.slim_column OWNER TO wcdgvfyqvpvazx;

--
-- Name: column_id_seq; Type: SEQUENCE; Schema: public; Owner: wcdgvfyqvpvazx
--

CREATE SEQUENCE public.column_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.column_id_seq OWNER TO wcdgvfyqvpvazx;

--
-- Name: column_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: wcdgvfyqvpvazx
--

ALTER SEQUENCE public.column_id_seq OWNED BY public.slim_column.id;


--
-- Name: slim_task; Type: TABLE; Schema: public; Owner: wcdgvfyqvpvazx
--

CREATE TABLE public.slim_task (
    id bigint NOT NULL,
    column_id integer NOT NULL,
    name character varying(250) NOT NULL,
    weight integer NOT NULL,
    description character varying(250),
    assigned_user_id integer
);


ALTER TABLE public.slim_task OWNER TO wcdgvfyqvpvazx;

--
-- Name: slim_user; Type: TABLE; Schema: public; Owner: wcdgvfyqvpvazx
--

CREATE TABLE public.slim_user (
    id integer NOT NULL,
    name character varying(250) NOT NULL,
    login character varying(250) NOT NULL,
    password character varying(250) NOT NULL
);


ALTER TABLE public.slim_user OWNER TO wcdgvfyqvpvazx;

--
-- Name: task_id_seq; Type: SEQUENCE; Schema: public; Owner: wcdgvfyqvpvazx
--

CREATE SEQUENCE public.task_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.task_id_seq OWNER TO wcdgvfyqvpvazx;

--
-- Name: task_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: wcdgvfyqvpvazx
--

ALTER SEQUENCE public.task_id_seq OWNED BY public.slim_task.id;


--
-- Name: user_id_seq; Type: SEQUENCE; Schema: public; Owner: wcdgvfyqvpvazx
--

CREATE SEQUENCE public.user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_id_seq OWNER TO wcdgvfyqvpvazx;

--
-- Name: user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: wcdgvfyqvpvazx
--

ALTER SEQUENCE public.user_id_seq OWNED BY public.slim_user.id;


--
-- Name: slim_board id; Type: DEFAULT; Schema: public; Owner: wcdgvfyqvpvazx
--

ALTER TABLE ONLY public.slim_board ALTER COLUMN id SET DEFAULT nextval('public.board_id_seq'::regclass);


--
-- Name: slim_column id; Type: DEFAULT; Schema: public; Owner: wcdgvfyqvpvazx
--

ALTER TABLE ONLY public.slim_column ALTER COLUMN id SET DEFAULT nextval('public.column_id_seq'::regclass);


--
-- Name: slim_task id; Type: DEFAULT; Schema: public; Owner: wcdgvfyqvpvazx
--

ALTER TABLE ONLY public.slim_task ALTER COLUMN id SET DEFAULT nextval('public.task_id_seq'::regclass);


--
-- Name: slim_user id; Type: DEFAULT; Schema: public; Owner: wcdgvfyqvpvazx
--

ALTER TABLE ONLY public.slim_user ALTER COLUMN id SET DEFAULT nextval('public.user_id_seq'::regclass);


--
-- Data for Name: slim_board; Type: TABLE DATA; Schema: public; Owner: wcdgvfyqvpvazx
--

COPY public.slim_board (id, name, description) FROM stdin;
\.
COPY public.slim_board (id, name, description) FROM '$$PATH$$/3861.dat';

--
-- Data for Name: slim_column; Type: TABLE DATA; Schema: public; Owner: wcdgvfyqvpvazx
--

COPY public.slim_column (id, board_id, name, weight) FROM stdin;
\.
COPY public.slim_column (id, board_id, name, weight) FROM '$$PATH$$/3863.dat';

--
-- Data for Name: slim_task; Type: TABLE DATA; Schema: public; Owner: wcdgvfyqvpvazx
--

COPY public.slim_task (id, column_id, name, weight, description, assigned_user_id) FROM stdin;
\.
COPY public.slim_task (id, column_id, name, weight, description, assigned_user_id) FROM '$$PATH$$/3865.dat';

--
-- Data for Name: slim_user; Type: TABLE DATA; Schema: public; Owner: wcdgvfyqvpvazx
--

COPY public.slim_user (id, name, login, password) FROM stdin;
\.
COPY public.slim_user (id, name, login, password) FROM '$$PATH$$/3866.dat';

--
-- Name: board_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wcdgvfyqvpvazx
--

SELECT pg_catalog.setval('public.board_id_seq', 8, true);


--
-- Name: column_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wcdgvfyqvpvazx
--

SELECT pg_catalog.setval('public.column_id_seq', 24, true);


--
-- Name: task_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wcdgvfyqvpvazx
--

SELECT pg_catalog.setval('public.task_id_seq', 13, true);


--
-- Name: user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wcdgvfyqvpvazx
--

SELECT pg_catalog.setval('public.user_id_seq', 2, true);


--
-- Name: slim_board board_pkey; Type: CONSTRAINT; Schema: public; Owner: wcdgvfyqvpvazx
--

ALTER TABLE ONLY public.slim_board
    ADD CONSTRAINT board_pkey PRIMARY KEY (id);


--
-- Name: slim_column column_pkey; Type: CONSTRAINT; Schema: public; Owner: wcdgvfyqvpvazx
--

ALTER TABLE ONLY public.slim_column
    ADD CONSTRAINT column_pkey PRIMARY KEY (id);


--
-- Name: slim_task task_pkey; Type: CONSTRAINT; Schema: public; Owner: wcdgvfyqvpvazx
--

ALTER TABLE ONLY public.slim_task
    ADD CONSTRAINT task_pkey PRIMARY KEY (id);


--
-- Name: slim_user user_pkey; Type: CONSTRAINT; Schema: public; Owner: wcdgvfyqvpvazx
--

ALTER TABLE ONLY public.slim_user
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: fki_assigned_user_task_fk; Type: INDEX; Schema: public; Owner: wcdgvfyqvpvazx
--

CREATE INDEX fki_assigned_user_task_fk ON public.slim_task USING btree (assigned_user_id);


--
-- Name: fki_bord_column_fk; Type: INDEX; Schema: public; Owner: wcdgvfyqvpvazx
--

CREATE INDEX fki_bord_column_fk ON public.slim_column USING btree (board_id);


--
-- Name: fki_column_task_fk; Type: INDEX; Schema: public; Owner: wcdgvfyqvpvazx
--

CREATE INDEX fki_column_task_fk ON public.slim_task USING btree (column_id);


--
-- Name: slim_task assigned_user_task_fk; Type: FK CONSTRAINT; Schema: public; Owner: wcdgvfyqvpvazx
--

ALTER TABLE ONLY public.slim_task
    ADD CONSTRAINT assigned_user_task_fk FOREIGN KEY (assigned_user_id) REFERENCES public.slim_user(id);


--
-- Name: slim_column board_column_fk; Type: FK CONSTRAINT; Schema: public; Owner: wcdgvfyqvpvazx
--

ALTER TABLE ONLY public.slim_column
    ADD CONSTRAINT board_column_fk FOREIGN KEY (board_id) REFERENCES public.slim_board(id);


--
-- Name: slim_task column_task_fk; Type: FK CONSTRAINT; Schema: public; Owner: wcdgvfyqvpvazx
--

ALTER TABLE ONLY public.slim_task
    ADD CONSTRAINT column_task_fk FOREIGN KEY (column_id) REFERENCES public.slim_column(id);


--
-- Name: DATABASE d1m91lf36ouf80; Type: ACL; Schema: -; Owner: wcdgvfyqvpvazx
--

REVOKE CONNECT,TEMPORARY ON DATABASE d1m91lf36ouf80 FROM PUBLIC;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: wcdgvfyqvpvazx
--

REVOKE ALL ON SCHEMA public FROM postgres;
REVOKE ALL ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO wcdgvfyqvpvazx;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- Name: LANGUAGE plpgsql; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON LANGUAGE plpgsql TO wcdgvfyqvpvazx;


--
-- PostgreSQL database dump complete
--

